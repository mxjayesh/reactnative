import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Signin from './src/components/auth/signin/Signin';
import Forgotpassword from './src/components/auth/forgotpassword/Forgotpassword';
import Signup from './src/components/auth/signup/Signup';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect,useState } from 'react';
import Tabnavigation from './src/navigation/Tabnavigation';


const Stack = createNativeStackNavigator();

 


export default function App() {

  const [isLogin,setLogin] = useState(false);

  useEffect(()=>{
    console.log('use')
      // const data = await AsyncStorage.getItem('@mobile')
      // console.log(data)
      const data = AsyncStorage.getItem('@mobile');
      data.then(data=>{
        if(data){
          setLogin(true);
        }
      })
  },[])


  return (
    <NavigationContainer>
      <Stack.Navigator>
          <Stack.Screen name="signin" component={Signin} options={{headerShown:false}}/> 
          <Stack.Screen name="forgotpassword" component={Forgotpassword} options={{headerShown:false}}/> 
          <Stack.Screen name="signup" component={Signup} options={{headerShown:false}}/> 
          <Stack.Screen name="tabnavigation" component={Tabnavigation} options={{headerShown:false}}/> 
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
