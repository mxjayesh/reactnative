import { StyleSheet } from 'react-native'

const mstyle = StyleSheet.create({
    safeview:{
        flex:1
    },
    container:{
        flex: 1,
        backgroundColor: '#fff',
    },
    main:{
        flex:1,
        marginLeft:40,
        marginRight:40,
    },
    firstSection:{
        flex:2,
    },
    secondSection:{
        flex:2,
    },
    thirdSection:{
        flex:2,
    },
    Title:{
        fontWeight:'bold',
        fontSize:18
    },
    ilabel:{
        fontWeight:'500',
        fontSize:14,
        marginTop:4,
        marginBottom:4,
        marginLeft:5,
        marginRight:5,
        padding:0
    },
    input:{
        borderWidth:1,
        borderColor:'gray',
        padding:5,
        borderRadius:5,
        margin:5
    },
    btn:{
        backgroundColor:'#04af44',
        justifyContent:'center',
        alignItems: 'center',
        padding:9, 
        borderRadius:5,
        margin:5,
        fontWeight:'bold'
    },
    btntext:{
        color:'#ffffff',
        fontWeight:'bold'
    }
})


// ---------- for color -------------------

const mcolor = StyleSheet.create({
    green:{
        color:'red'
    },
    red :{
        color:'red'
    },
    blue :{
        color:'#1a66ff'
    },
    white:{
        color:'#FFFFFF'
    },
    black:{
        color:'#000000'
    }
})


// ----------- for flex -----------------

const mflex = StyleSheet.create({
    flex1:{
        flex:1
    },
    flex2:{
        flex:2
    },
    flex3:{
        flex:3
    },
    flex3:{
        flex:3
    }, 
    flex4:{
        flex:4
    }, 
    flex5:{
        flex:5
    }
})

export {mstyle,mcolor,mflex}
