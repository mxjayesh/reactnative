import { View,Text,SafeAreaView,StyleSheet, Image } from "react-native"
import { mstyle,mcolor } from '../../../../style'



const Profile = () => {
    return(
        <SafeAreaView style={mstyle.safeview}>
            <View style={mstyle.container}>
                <View style={style.firstsection}>
                    <View style={style.titlesection}>
                        <View style={{padding:0,flex:1,flexDirection:'row-reverse'}}>
                            <View style={style.imagesection}>
                                <Image style={style.userimage} source={require('../../../../assets/userimage.png')} />
                            </View>
                        </View>
                        <View style={style.profilenamesection}>
                            <Text style={[mcolor.white,style.hellotext]}>Hello</Text>
                            <Text style={[mcolor.white,style.username]}>Ashutosh</Text>
                        </View>
                    </View>
                </View>
                <View style={style.secondsection}>
                    <View style={style.walletsection}>
                        <View style={{flex:1,padding:10,alignSelf:'center'}}>
                            <Text style={{fontSize:19,fontWeight:'bold'}}>Wallet</Text>
                            <Text style={{fontSize:14,fontWeight:'400'}}>200 Points</Text>
                            <Text style={{fontSize:14,fontWeight:'400'}}>Reward points</Text>
                        </View>
                        <View style={{flex:1}}>
                                <Text>dfs</Text>
                        </View>
                    </View>
                </View>
                <View style={style.thirdsection}>
                    <View>
                        <Text>Jayesh</Text>
                    </View>
                </View>
            </View>
        </SafeAreaView>
        
    ) 
}

const style = StyleSheet.create({
    firstsection:{
          height:110,
          backgroundColor: '#04af44'
    },
    titlesection:{
        flex:1,
        padding:16,
        flexDirection:'row',
    },
    imagesection:{
        width:80,
        height:80,
        backgroundColor:'white',
        borderRadius:100,
        borderWidth:2,
        borderColor:'white',
        flexDirection:'column-reverse'
    },
    userimage:{
        resizeMode: 'contain',
        flex: 1,
        width: '100%',
        height: '100%'
    },
    profilenamesection:{
        marginLeft:23,
        alignSelf:'center',
        flex:3
    },
    hellotext:{
        marginTop:20,
        fontSize:20,
        fontWeight:'bold'
    },
    username:{
        fontSize:16,
        fontWeight:'400'
    },
    secondsection :{
        flex:1
    },
    walletsection :{
        flex:1,
        flexDirection:'row',
        margin:10,
        padding:5,
        borderRadius: 5,
        borderWidth: 1,
        borderColor:'#fff',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.25,
        shadowRadius: 0.84,
        elevation: 1,
    },

    thirdsection:{
        flex:4,
    }
})

export default Profile;

// wallet 
// 200 points
// reward points