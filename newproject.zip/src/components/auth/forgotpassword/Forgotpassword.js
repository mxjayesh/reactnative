import {View,Text,SafeAreaView,StyleSheet, TextInput,TouchableHighlight} from 'react-native';
import { mstyle,mcolor } from '../../../../style';


const Forgotpassword = () => {
    return(
        <SafeAreaView>
            <View>
                <Text>Registration</Text>
            </View>
        </SafeAreaView>
    )
}


export default Forgotpassword;