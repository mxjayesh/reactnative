import {useState} from 'react';
import {View,Text,SafeAreaView,StyleSheet, TextInput,TouchableHighlight,ActivityIndicator,Keyboard} from 'react-native';
import { mstyle,mcolor } from '../../../../style';
import { useValidation } from 'react-native-form-validator';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Signin = ({navigation}) => {

    const [loginLoader,setloginLoader] = useState(false);
    const [mobilenumber,setmobilenumber] = useState('');

    const { validate, isFieldInError, getErrorsInField, getErrorMessages } =
    useValidation({
      state: { mobilenumber },
    });

    const login = async () =>{

        try{
            const isValidate = validate({
                mobilenumber: {required: true }
            });

            //is validated
            if(isValidate){
                await AsyncStorage.setItem('@mobile', mobilenumber)
                navigation.navigate('tabnavigation')
            }else{
                setloginLoader(false);
                // return false;
            }   
        }catch(e){
            console.log(e)
        }

        setloginLoader(false);
        setmobilenumber('')
       
        
        
    }

    return(
        <SafeAreaView style={mstyle.safeview}>
            <View style={mstyle.container}>
                <View style={style.main}>
                    <View style={style.firstSection}>
                        <Text style={mcolor.green}>1</Text>
                    </View>
                    <View style={style.secondSection}>
                        <Text style={style.Title}>Hey, Welcome back</Text>
                        
                        <View style={{marginTop:20}}>
                            <Text style={mstyle.ilabel}>
                                Mobile Number 
                                <Text style={mcolor.red}> *</Text>
                            </Text>
                            <TextInput 
                                placeholder='Enter mobile number'
                                keyboardType='numeric'
                                maxLength={10}
                                style = {mstyle.input}
                                onChangeText={setmobilenumber}
                                value={mobilenumber}
                            />
                             {  isFieldInError('mobilenumber') &&
                                getErrorsInField('mobilenumber').map(errorMessage => (
                                <Text key={errorMessage} style={[{marginLeft:5},mcolor.red]}>Mobile number is required</Text>
                                ))}
                            <View>
                                <Text style={{fontWeight:'bold',margin:5,textAlign:'center'}}>
                                    Don't Remember! <Text style={mcolor.blue} onPress={()=>{navigation.navigate('forgotpassword')}}>
                                         Forgot password
                                    </Text>
                                </Text>
                            </View>
                            <TouchableHighlight style={mstyle.btn} onPress={()=>{ Keyboard.dismiss(); setloginLoader(true); login() }}>
                                <View>
                                    {  loginLoader 
                                        ? <Text><ActivityIndicator size="small" color="#ffff" /></Text>
                                        : <Text style={mstyle.btntext}>Login</Text>  
                                    }
                                </View>
                            </TouchableHighlight>
                            <View style={{alignItems: 'center'}}>
                                <Text style={{fontWeight:'bold',margin:5}}>
                                    Don't have an account! <Text style={mcolor.blue} onPress={()=>{navigation.navigate('signup')}}>Registration</Text>
                                </Text>
                            </View>
                        </View>
                        
                    </View>
                    <View style={style.thirdSection}>
                        <Text>3</Text>
                    </View>
                </View>
            </View>
        </SafeAreaView>
    )
}


const style = StyleSheet.create({
    main:{
        flex:1,
        marginLeft:40,
        marginRight:40,
    },
    firstSection:{
        flex:2,
    },
    secondSection:{
        flex:2,
    },
    thirdSection:{
        flex:2,
    },
    Title:{
        fontWeight:'bold',
        fontSize:20
    }
})


export default Signin;