import {View,Text,SafeAreaView,StyleSheet, TextInput,TouchableHighlight} from 'react-native';
import { mstyle,mcolor } from '../../../../style';


const Signup = () => {
    return(
        <SafeAreaView>
            <View>
                <Text>Signup</Text>
            </View>
        </SafeAreaView>
    )
}


export default Signup;