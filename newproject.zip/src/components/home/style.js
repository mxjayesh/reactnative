import { StyleSheet } from 'react-native'

const style = StyleSheet.create({
    
});



export default style;