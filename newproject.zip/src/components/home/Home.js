import { useLayoutEffect,useEffect,useState } from 'react';
import {View,Text,SafeAreaView,StyleSheet, TextInput,TouchableHighlight,Button} from 'react-native';
import { mstyle,mflex,mcolor } from '../../../style';
import Icon from 'react-native-vector-icons/Ionicons';
import * as Location from 'expo-location';

const Home = ({navigation}) => {
    
    const [location,setLocation] = useState('Nashik')
    

    useEffect(() => {
        console.log('2')
        console.log(location)
        navigation.setOptions({
          headerRight: () => (
            <View style={{flex:1,flexDirection:'row',alignItems:'center'}}>
                <Text style={{marginHorizontal:2, fontSize:14,fontWeight:'bold'}}>{location}</Text>
                <Icon name='location-outline' size={21} color="#181823" style={{marginRight:7}} />
            </View>
          ),
        });
      }, [navigation,location]);


    return(
        <SafeAreaView style={mstyle.safeview}>
             <View style={mstyle.container}>
                <View style={style.firstsection}>
                    <View style={style.titlesection}>
                        <Text style={[mcolor.white,style.title]}>Welcome</Text>
                        <Text style={[mcolor.white,style.label]}>It's Smart Solution for Shoppy</Text>
                    </View>
                </View>
                <View style={style.mainsection}>
                    <Text>sdf</Text>
                </View>
            </View>
        </SafeAreaView>
    )
}


const style = StyleSheet.create({
    firstsection:{
          height:110,
          backgroundColor: '#04af44',
          padding:10
    },
    titlesection:{
        flex:1,
        padding:16,
        justifyContent:'center'
    },
    mainsection :{
        flex:1
    },
    title:{
        fontSize:19,
        fontWeight:'bold',
    },
    label:{
        fontSize:15,
        marginTop:5
    }
})

export default Home;