import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/Ionicons';
import Home from '../components/home/Home';

import {mcolor} from '../../style';
import Profile from '../components/profilemodule/profile/Profile';

const Tab = createBottomTabNavigator();

const tabStyle ={
    tabBarLabelStyle:{fontSize:10.5,fontWeight:'500'},
    tabBarActiveTintColor:mcolor.black.color
}

const Tabnavigation = () => {
    return (
        <Tab.Navigator >
          <Tab.Screen name="Home" component={Home} options={{tabBarIcon:(props)=><BottomTabIcon icon='home'/>,...tabStyle}}/>
          <Tab.Screen name="Buy" component={Home} options={{tabBarIcon:(props)=><BottomTabIcon icon='cart'/>,...tabStyle}}/>
          <Tab.Screen name="Sell" component={Home} options={{tabBarIcon:(props)=><BottomTabIcon icon='cube'/>,tabBarLabel:()=>{return null}}}/>
          <Tab.Screen name="Rates" component={Home} options={{tabBarIcon:(props)=><BottomTabIcon icon='list'/>,...tabStyle}}/>
          <Tab.Screen name="Profile" component={Profile} options={{tabBarIcon:(props)=><BottomTabIcon icon='person'/>,...tabStyle}}/>
        </Tab.Navigator>
      );
}  


const BottomTabIcon = (props) => {
  if(props.icon == 'cube'){
    return <Icon name={props.icon} size={30} color="#fff" style={{marginTop:-21,backgroundColor:'#04af44',borderRadius:50,padding:12}}/>;
  }
  return <Icon name={props.icon} size={20} color="#181823" />;
}

export default Tabnavigation;